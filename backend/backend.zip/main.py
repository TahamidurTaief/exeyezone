def main():
    print("Hello from backend!")


if __name__ == "__main__":
    main()
