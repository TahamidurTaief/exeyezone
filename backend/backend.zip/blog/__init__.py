"""
Blog App - SEO Optimized Backend
Production-ready blog system with comprehensive SEO features.
"""

default_app_config = 'blog.apps.BlogConfig'
